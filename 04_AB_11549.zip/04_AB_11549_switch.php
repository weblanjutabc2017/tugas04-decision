<?php
	$nilai = "B+";

	switch($nilai){
		case $nilai=="A" or $nilai=="A-" or $nilai=="A/B" or $nilai=="B+" or $nilai=="B" or $nilai=="B-" or $nilai=="B/C":
			echo "LULUS";
			break;
		case $nilai=="C+" or $nilai=="C" or $nilai=="C-" or $nilai=="C/D":
			echo "LULUS SEBAIKNYA DIULANG";
			break;
		case $nilai=="D+" or $nilai=="D":
			echo "LULUS & WAJIB DIULANG";
			break;
		case $nilai=="E":
			echo "TIDAK LULUS";
			break;
		default;
			echo "Nilai yang dimasukkan salah";
			break;    
	}

	/*
		Muhammad Rohman Irfanuddin
		16/401045/SV/11549
	*/

?>