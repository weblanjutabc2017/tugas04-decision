<?php
	$nilai = "E";

	if($nilai=="A" or $nilai=="A-" or $nilai=="A/B" or $nilai=="B+" or $nilai=="B" or $nilai=="B-" or $nilai=="B/C"){
		echo "LULUS";
	}
	else if($nilai=="C+" or $nilai=="C" or $nilai=="C-" or $nilai=="C/D"){
		echo "LULUS SEBAIKNYA DIULANG";
	}
	else if($nilai=="D+" or $nilai=="D"){
		echo "LULUS & WAJIB DIULANG";
	}
	else{
		echo "TIDAK LULUS";
	}

	/*
		Muhammad Rohman Irfanuddin
		16/401045/SV/11549
		Praktikum AB
	*/
?>

